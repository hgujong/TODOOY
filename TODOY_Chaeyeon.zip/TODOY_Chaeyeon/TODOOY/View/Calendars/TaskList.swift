//
//  TaskList.swift
//  TaskwithFirebase
//
//  Created by 이채연 on 2023/01/05.
//

import SwiftUI
import Firebase

struct TaskList: View {
    @State var task = ""
    @State var data = [Task]()
    @State var keyVal: CGFloat = 0
    let db = Firestore.firestore()
    func getData(){
        db.collection("data").document("user").collection("tasks").order(by: "date",descending: true).addSnapshotListener{ (query, err) in
            guard let documents = query?.documents else {
                print(err!.localizedDescription)
                return
            }
            if err != nil{
                print(err!.localizedDescription)
            }
            let task = documents.map { $0["task"]! }
            let date = documents.map { $0["date"]! }
            let done = documents.map { $0["done"]! }
            
            self.data.removeAll()
            
            for i in 0..<documents.count {
                self.data.append(Task(id: documents[i].documentID, task: task[i] as! String, date: date[i] as! Timestamp, done: done[i] as! Bool))
            }
        }
    }
    
    func save(task: String) {
        db.collection("data").document("user").collection("tasks").addDocument(data: ["task" : task, "done" : false, "date" : Date()
        ])
    }
    
    func update(docID: String, done: Bool){
        db.collection("data").document("user").collection("tasks").document(docID).updateData([
                "done": done
        ])
    }
    
    func moveKeyboard(){
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: .main){
            (not) in
            let value = not.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! CGRect
            let height = value.height
            self.keyVal = height
        }
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: .main){
            (not) in
            
            self.keyVal = 0
        }
    }
    
    func delete(at offsets: IndexSet) {
        db.collection("data").document("user").collection("tasks").document(self.data[offsets.first!].id).delete()
    }
    
    var body: some View {
        NavigationView{
            VStack{
                List{
                    ForEach(self.data) {i in
                        Button(action: {
                            self.update(docID: i.id, done: !i.done)
                            
                        }) {
                            HStack{
                                if i.done{
                                    Image(systemName: "circle.fill")
                                } else{
                                    Image(systemName: "circle")
                                }
                                Text(i.task)
                            }
                        }
                    }
                    .onDelete { (index) in
                        self.delete(at: index)
                    }
                }
                HStack{
                    TextField("Task",text: $task)
                    Button(action: {
                        self.save(task: self.task)
                        self.task = ""
                        UIApplication.shared.endEditing()
                        
                    }) {
                        Text("Save")
                    }
                }
                .padding().background(Color.white)
            }
            .navigationBarTitle("Tasks")
            .onAppear {
                self.getData()
                self.moveKeyboard()
            }
        }
    }
}

struct Task:Identifiable{
    var id: String
    var task: String
    var date: Timestamp
    var done: Bool
}

struct TaskList_Previews: PreviewProvider {
 static var previews: some View {
     TaskList()
 }
}
 

extension UIApplication{
    func endEditing(){
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
