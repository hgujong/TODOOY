//
//  FriendHome.swift
//  TODO
// 
//  Created by 서종현 on 2022/12/22.
//

import SwiftUI

struct FriendHome: View {
    var body: some View {
        FriendsList()
    }
}

struct FriendHome_Previews: PreviewProvider {
    static var previews: some View {
        FriendHome()
    }
}
