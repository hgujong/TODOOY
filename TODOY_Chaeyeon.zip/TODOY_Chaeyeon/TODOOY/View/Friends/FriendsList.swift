//
//  FriendsList.swift
//  friends
//
//  Created by 이채연 on 2022/12/30.
//

import SwiftUI

struct FriendsList: View {
    
    struct FriendList: Identifiable {
        let id = UUID()
        var content: String
    }
    
    @State var friend = ""
    @State private var friendLists = [FriendList]()
    
    var body: some View {
        NavigationView{
            VStack {
                //Text("What to do Today?")
                    //Fri.font(.title.bold())
                
                HStack {
                    Image(systemName: "plus")
                    TextField(
                        "New Friends",
                        text: $friend,
                        onCommit: {
                            appendList()
                        }
                    )
                }
                .textFieldStyle(DefaultTextFieldStyle())
                .frame(width: 300, height: 50, alignment: .center)
                
                List {
                    ForEach(0..<friendLists.count, id: \.self) { i in
                        HStack {
                            Image(systemName: "person")
                            Text(friendLists[i].content)
                            Spacer()
                            //Button(
                                //action: {
                                    //deleteList(i)
                                //},
                                //label: {
                                    //Image(systemName: "trash")
                                //}
                            //)
                            
                        }
                        //.buttonStyle(BorderlessButtonStyle())
                        
                    }
                    .onDelete { indexSet in
                        friendLists.remove(atOffsets: indexSet)
                    }
                }
                .toolbar {
                    EditButton()
                }
                
            }
            .navigationTitle("Friends")
            
        }
    }
    
    func appendList() {
         let inputList = FriendList(content: friend)
         friendLists.append(inputList)
         friend = ""
     }
    
    //func deleteList(_ i: Int) {
        //todoLists.remove(at: i)
    //}
}

struct FriendsList_Previews: PreviewProvider {
    static var previews: some View {
        FriendsList()
    }
}
